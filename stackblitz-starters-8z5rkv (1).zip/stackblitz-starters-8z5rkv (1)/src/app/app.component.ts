import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-dashboard></app-dashboard>'
})
export class AppComponent { }